;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ABM de Enchentes em NetLogo
;; Simulação para enchentes em uma cidade com edifícios e habitantes
;;TCC - Mattedi - 2024
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Definição das breads
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
breed [habitantes habitante]
breed [edificios edificio]

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Definição das variáveis de cada patch (um mesmo pacth pode ter várias variaveois)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
patches-own [
  elevacao ;altimetria (metro quadrado)
  agua-nivel ;cota (metros quadrados)
  densidade-edilicia ; DE
  densidade-demografica ; DD
  centro;
  V ;; Vulnerabilidade
  D ;; Desastre
]

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Configuração do Modelo
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
globals [
  patches-inundados
  habitantes-afetados
  edificios-afetados
  condicao-enchente
  centros
  populacao-total
  num-edificios
  lista-edificios
  permeabilidade
]

habitantes-own [ saude ] ; Declara a variável 'saude' para os habitantes (grau de impacto)

edificios-own [ integridade ] ; Declara a variável 'integridade' para os edifícios (grau de impacto)

to setup
  clear-all
  ;set alfa 0.0
  ;set beta 0.0
  ;set gama 0.0
  ;set δ 0.0
  set centros sort n-of 3 patches
  ask patches [ setup-terreno ]
  set lista-edificios []  ; Inicializa a lista de edifícios
  distribuir-edificios ; Chama a função para distribuir os edifícios
  setup-edificios
  setup-habitantes
  set dias-impactados 1;
  print "Simulação Enchentes em Blumenau"
  reset-ticks
end

to distribuir-edificios
  ; Cria a quantidade de edifícios definida pelo slider
  ; num-edificios armazena a quantidade definida pelo slider
  create-edificios num-edificios [
    set color yellow
    set size 1
    set integridade integridade-inicial
    move-to one-of patches with [elevacao >= 7 and elevacao <= 30]
    set lista-edificios lput self lista-edificios  ; Adiciona o edifício à lista
  ]
end

to distribuir-populacao
  ; Cria a quantidade de habitantes definida pelo slider
  create-habitantes populacao-total [
    set color magenta
    set size 1
    move-to one-of patches with [elevacao >= 7 and elevacao <= 20] ; Distribui os habitantes pelos patches habitáveis
    set saude saude-inicial ; Define a saúde após a criação do habitante
  ]
end

to setup-terreno
  ; Configura o ambiente e as características de cada patch (célula da grade espacial) no terreno
   if member? self centros [
    set centro self
  ]
  let centro1 item 0 centros
  let centro2 item 1 centros
  let centro3 item 2 centros
  let dist1 distance centro1
  let dist2 distance centro2
  let dist3 distance centro3
  set elevacao 30 - min (list dist1 dist2 dist3)
  if elevacao < 0 [ set elevacao 0 ]
  set agua-nivel 3
  set pcolor scale-color brown elevacao 30 0
  set V 0          ; Inicializa a vulnerabilidade
  set D 0          ; Inicializa o dano
end

to setup-edificios
  ask patches with [elevacao >= 7 and elevacao <= 20] [
    set densidade-edilicia random 10
    if densidade-edilicia > 0 [
      sprout-edificios densidade-edilicia [
        set color red
        set size 1
        set shape "house colonial"
        set integridade 10
      ]
    ]
  ]
end

to setup-habitantes
  ask patches with [elevacao >= 7 and elevacao <= 20] [
    set densidade-demografica random 5
    if densidade-demografica > 0 [
      sprout-habitantes densidade-demografica [
        set size 1
        set shape "person student"
        set color yellow
        set saude 10
      ]
    ]
  ]
end

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Definindo o nível de água para tipos de enchente
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
to iniciar-enchente-pequeno-porte
  set condicao-enchente "Pequeno Porte"
  setar-nivel-agua 7.5 10.0
end

to iniciar-enchente-medio-porte
  set condicao-enchente "Médio Porte"
  setar-nivel-agua 10.3 13.0
end

to iniciar-enchente-grande-porte
  set condicao-enchente "Grande Porte"
  setar-nivel-agua 13.0 15.0
end

to setar-nivel-agua [min-level max-level]
  ask patches [
    if elevacao < max-level [
      set agua-nivel (random-float (max-level - min-level) + min-level)
      if agua-nivel > elevacao [
        set pcolor blue
      ]
    ]
  ]
end

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Definindo o nível de água para tipos de enchente
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
to go
  if ticks >= dias-impactados [ stop ];
  aumentar-nivel-agua
  atualizar-cores
  calculate-vulnerability
  calculate-damage
  atualizar-contagem-afetados
  update-vulnerability-heatmap ;; Atualiza o gráfico de calor da vulnerabilidade
  update-damage-heatmap    ;; Atualiza o gráfico de calor do dano
  set dias-impactados ticks  ;
  print "Simulação Enchentes em Blumenau"
  tick
end

to aumentar-nivel-agua
  ask patches [
    let aumento 0
    if condicao-enchente = "Pequeno Porte" [ set aumento intensidade-chuva * (1 - permeabilidade) * (1 / (elevacao + 1)) ] ; Aumento menor com maior elevação
    if condicao-enchente = "Médio Porte" [ set aumento intensidade-chuva * (1 - permeabilidade) * (1 / (elevacao + 1)) * 1.5 ] ; Aumento médio
    if condicao-enchente = "Grande Porte" [ set aumento intensidade-chuva * (1 - permeabilidade) * (1 / (elevacao + 1)) * 2 ] ; Aumento maior

    ; Influência da densidade edilicia e demográfica
    set aumento aumento * (1 + (densidade-edilicia + densidade-demografica) / 10)

    set agua-nivel agua-nivel + aumento

    if agua-nivel > elevacao [
      set pcolor blue
    ]
  ]
end

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Atualização da cor dos patches
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
to atualizar-cores
  ask patches [
    ifelse agua-nivel > elevacao [ ; Se o patch estiver inundado
      ; ... código para definir a cor do patch inundado ...
      ask habitantes-here [
        if saude < 5 [
          set color red  ; Pessoas afetadas (saúde baixa) ficam vermelhas
        ]
      ]
      ask edificios-here [
        if integridade < 5 [
          set color orange ; Edifícios afetados (integridade baixa) ficam laranja
        ]
      ]
    ] [
      ; ... código para definir a cor do patch não inundado ...
      ask habitantes-here [ set color magenta ] ; Pessoas não afetadas continuam magenta
      ask edificios-here [ set color yellow ]   ; Edifícios não afetados continuam amarelos
    ]
  ]
end

to atualizar-contagem-afetados
  set patches-inundados count patches with [agua-nivel > elevacao]
  set habitantes-afetados count habitantes with [agua-nivel > elevacao]
  set edificios-afetados count edificios with [agua-nivel > elevacao]
end

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Calcula as formulas
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
to calculate-vulnerability
  ask patches [
    set V alfa * densidade-demografica + beta * densidade-edilicia + gama * agua-nivel
  ]
end

to calculate-damage
  ask patches with [agua-nivel > elevacao] [
    ask habitantes-here [
      set saude saude - (δ * V)
      if saude < 0 [ set saude 0 ]
    ]
    ask edificios-here [
      set integridade integridade - (δ * V)
      if integridade < 0 [ set integridade 0 ]
    ]

    let dano-habitantes sum [10 - saude] of habitantes-here  ; Calcula o dano total dos habitantes
    let dano-edificios sum [10 - integridade] of edificios-here ; Calcula o dano total dos edifícios
    set D dano-habitantes + dano-edificios  ; Soma o dano de habitantes e edifícios
  ]
end

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Plotagem
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
to update-vulnerability-heatmap
  ask patches with [agua-nivel > elevacao] [ ; Altera a cor apenas dos patches inundados
    set pcolor scale-color red V 0 max [V] of patches
  ]
  ; Define as cores das tartarugas para visibilidade
  ask edificios [
    set color yellow
  ]
  ask habitantes [
    set color magenta
  ]
end

to update-damage-heatmap
  ask patches with [agua-nivel > elevacao] [ ; Altera a cor apenas dos patches inundados
    set pcolor scale-color blue D 0 max [D] of patches
  ]
  ; Redefinir cores das tartarugas para visibilidade
  ask edificios [
    set color yellow
  ]
  ask habitantes [
    set color magenta
  ]
end
@#$#@#$#@
GRAPHICS-WINDOW
546
10
1347
812
-1
-1
13.0
1
10
1
1
1
0
1
1
1
-30
30
-30
30
0
0
1
ticks
30.0

BUTTON
36
157
133
190
   -SETUP-   
setup
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
32
441
145
474
Pequeno Porte
iniciar-enchente-pequeno-porte
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
164
441
275
474
  Medio Porte  
iniciar-enchente-medio-porte
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
296
442
415
475
  Grande Porte  
iniciar-enchente-grande-porte
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
159
157
259
190
      -GO-      
go
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

PLOT
1384
156
1775
306
Vulnerabilidade Média
Tempo
Vulnerabilidade
0.0
10.0
0.0
100.0
false
true
"" ""
PENS
"Impacto" 1.0 0 -13840069 true "" "plot mean [D] of patches"
"Vulnerabilidade" 1.0 0 -2139308 true "" "plot mean [V] of patches"

SLIDER
33
251
205
284
População
População
100000
500000
156055.0
1
1
NIL
HORIZONTAL

SLIDER
35
296
207
329
Edifícios
Edifícios
10000
100000
40955.0
1
1
NIL
HORIZONTAL

SLIDER
28
512
61
604
alfa
alfa
0
3
2.0
1
1
NIL
VERTICAL

SLIDER
75
513
108
605
beta
beta
0
3
2.0
1
1
NIL
VERTICAL

SLIDER
123
514
156
606
gama
gama
0
3
2.0
1
1
NIL
VERTICAL

SLIDER
170
513
203
605
δ
δ
0
3
2.0
1
1
NIL
VERTICAL

BUTTON
284
158
372
191
Go Rápido
go
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

MONITOR
1385
488
1456
521
Patches
patches-inundados
0
1
8

MONITOR
1478
488
1545
521
População
habitantes-afetados
0
1
8

MONITOR
1566
490
1623
523
Edifícios
edificios-afetados
0
1
8

MONITOR
1386
539
1471
584
  Máximo Vul 
max [V] of patches
4
1
11

MONITOR
1480
539
1562
584
    Média Vul 
mean [V] of patches
4
1
11

MONITOR
1387
593
1474
638
Máximo Dano
max [D] of patches
4
1
11

MONITOR
1482
593
1567
638
  Média Dano
mean [D] of patches
4
1
11

SLIDER
37
344
209
377
dias-impactados
dias-impactados
1
7
0.0
1
1
NIL
HORIZONTAL

TEXTBOX
30
122
180
140
  Comandos de Controle
12
15.0
0

TEXTBOX
33
216
183
234
 Configuração do Ambiente
12
15.0
1

TEXTBOX
35
408
185
438
Dimensionamento do Impacto
11
15.0
1

TEXTBOX
220
517
370
629
alfa = influência de DD em V\n(+DD/patch = +V)\nbeta = Influência de DE em V\n(+DE/patch = +V) \ngama = influência de E em V\n(+agua = +V) \nomega = intensidade de E\n(ESCALA: 1 a 4)
11
15.0
1

TEXTBOX
51
478
132
500
(7.30m - 10.0m)
9
15.0
1

TEXTBOX
181
478
275
496
(10.0m - 13.0m)
10
15.0
1

TEXTBOX
326
479
386
497
(<13.0m)
11
15.0
1

SLIDER
222
251
394
284
saude-inicial
saude-inicial
0
100
20.0
1
1
NIL
HORIZONTAL

SLIDER
221
296
393
329
integridade-inicial
integridade-inicial
0
100
39.0
1
1
NIL
HORIZONTAL

SLIDER
223
346
395
379
intensidade-chuva
intensidade-chuva
0
200
158.0
1
1
NIL
HORIZONTAL

PLOT
1385
322
1766
472
Síntese dos dados
NIL
NIL
0.0
10.0
0.0
10.0
true
true
"" ""
PENS
"População Impactados" 1.0 0 -2674135 true "" "plot habitantes-afetados"
"Pachts Impacatods" 1.0 0 -16777216 true "" "plot patches-inundados"
"Edifícios Impactados" 1.0 0 -13840069 true "" "plot edificios-afetados"
"Vulnerabilidade Máxima" 1.0 0 -13791810 true "" "plot max [V] of patches"
"Dano Máximo" 1.0 0 -987046 true "" "plot max [D] of patches"

TEXTBOX
167
40
401
138
ENTRADAS
40
15.0
1

TEXTBOX
1467
32
1617
81
SAÍDAS
40
65.0
1

@#$#@#$#@
## WHAT IS IT?

(a general understanding of what the model is trying to show or explain)

## HOW IT WORKS

(what rules the agents use to create the overall behavior of the model)

## HOW TO USE IT

(how to use the model, including a description of each of the items in the Interface tab)

## THINGS TO NOTICE

(suggested things for the user to notice while running the model)

## THINGS TO TRY

(suggested things for the user to try to do (move sliders, switches, etc.) with the model)

## EXTENDING THE MODEL

(suggested things to add or change in the Code tab to make the model more complicated, detailed, accurate, etc.)

## NETLOGO FEATURES

(interesting or unusual features of NetLogo that the model uses, particularly in the Code tab; or where workarounds were needed for missing features)

## RELATED MODELS

(models in the NetLogo Models Library and elsewhere which are of related interest)

## CREDITS AND REFERENCES

(a reference to the model's URL on the web if it has one, as well as any other necessary credits, citations, and links)
@#$#@#$#@
default
true
0
Polygon -7500403 true true 150 5 40 250 150 205 260 250

airplane
true
0
Polygon -7500403 true true 150 0 135 15 120 60 120 105 15 165 15 195 120 180 135 240 105 270 120 285 150 270 180 285 210 270 165 240 180 180 285 195 285 165 180 105 180 60 165 15

arrow
true
0
Polygon -7500403 true true 150 0 0 150 105 150 105 293 195 293 195 150 300 150

box
false
0
Polygon -7500403 true true 150 285 285 225 285 75 150 135
Polygon -7500403 true true 150 135 15 75 150 15 285 75
Polygon -7500403 true true 15 75 15 225 150 285 150 135
Line -16777216 false 150 285 150 135
Line -16777216 false 150 135 15 75
Line -16777216 false 150 135 285 75

bug
true
0
Circle -7500403 true true 96 182 108
Circle -7500403 true true 110 127 80
Circle -7500403 true true 110 75 80
Line -7500403 true 150 100 80 30
Line -7500403 true 150 100 220 30

butterfly
true
0
Polygon -7500403 true true 150 165 209 199 225 225 225 255 195 270 165 255 150 240
Polygon -7500403 true true 150 165 89 198 75 225 75 255 105 270 135 255 150 240
Polygon -7500403 true true 139 148 100 105 55 90 25 90 10 105 10 135 25 180 40 195 85 194 139 163
Polygon -7500403 true true 162 150 200 105 245 90 275 90 290 105 290 135 275 180 260 195 215 195 162 165
Polygon -16777216 true false 150 255 135 225 120 150 135 120 150 105 165 120 180 150 165 225
Circle -16777216 true false 135 90 30
Line -16777216 false 150 105 195 60
Line -16777216 false 150 105 105 60

car
false
0
Polygon -7500403 true true 300 180 279 164 261 144 240 135 226 132 213 106 203 84 185 63 159 50 135 50 75 60 0 150 0 165 0 225 300 225 300 180
Circle -16777216 true false 180 180 90
Circle -16777216 true false 30 180 90
Polygon -16777216 true false 162 80 132 78 134 135 209 135 194 105 189 96 180 89
Circle -7500403 true true 47 195 58
Circle -7500403 true true 195 195 58

circle
false
0
Circle -7500403 true true 0 0 300

circle 2
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240

cow
false
0
Polygon -7500403 true true 200 193 197 249 179 249 177 196 166 187 140 189 93 191 78 179 72 211 49 209 48 181 37 149 25 120 25 89 45 72 103 84 179 75 198 76 252 64 272 81 293 103 285 121 255 121 242 118 224 167
Polygon -7500403 true true 73 210 86 251 62 249 48 208
Polygon -7500403 true true 25 114 16 195 9 204 23 213 25 200 39 123

cylinder
false
0
Circle -7500403 true true 0 0 300

dot
false
0
Circle -7500403 true true 90 90 120

face happy
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 255 90 239 62 213 47 191 67 179 90 203 109 218 150 225 192 218 210 203 227 181 251 194 236 217 212 240

face neutral
false
0
Circle -7500403 true true 8 7 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Rectangle -16777216 true false 60 195 240 225

face sad
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 168 90 184 62 210 47 232 67 244 90 220 109 205 150 198 192 205 210 220 227 242 251 229 236 206 212 183

factory
false
0
Rectangle -7500403 true true 76 194 285 270
Rectangle -7500403 true true 36 95 59 231
Rectangle -16777216 true false 90 210 270 240
Line -7500403 true 90 195 90 255
Line -7500403 true 120 195 120 255
Line -7500403 true 150 195 150 240
Line -7500403 true 180 195 180 255
Line -7500403 true 210 210 210 240
Line -7500403 true 240 210 240 240
Line -7500403 true 90 225 270 225
Circle -1 true false 37 73 32
Circle -1 true false 55 38 54
Circle -1 true false 96 21 42
Circle -1 true false 105 40 32
Circle -1 true false 129 19 42
Rectangle -7500403 true true 14 228 78 270

fish
false
0
Polygon -1 true false 44 131 21 87 15 86 0 120 15 150 0 180 13 214 20 212 45 166
Polygon -1 true false 135 195 119 235 95 218 76 210 46 204 60 165
Polygon -1 true false 75 45 83 77 71 103 86 114 166 78 135 60
Polygon -7500403 true true 30 136 151 77 226 81 280 119 292 146 292 160 287 170 270 195 195 210 151 212 30 166
Circle -16777216 true false 215 106 30

flag
false
0
Rectangle -7500403 true true 60 15 75 300
Polygon -7500403 true true 90 150 270 90 90 30
Line -7500403 true 75 135 90 135
Line -7500403 true 75 45 90 45

flower
false
0
Polygon -10899396 true false 135 120 165 165 180 210 180 240 150 300 165 300 195 240 195 195 165 135
Circle -7500403 true true 85 132 38
Circle -7500403 true true 130 147 38
Circle -7500403 true true 192 85 38
Circle -7500403 true true 85 40 38
Circle -7500403 true true 177 40 38
Circle -7500403 true true 177 132 38
Circle -7500403 true true 70 85 38
Circle -7500403 true true 130 25 38
Circle -7500403 true true 96 51 108
Circle -16777216 true false 113 68 74
Polygon -10899396 true false 189 233 219 188 249 173 279 188 234 218
Polygon -10899396 true false 180 255 150 210 105 210 75 240 135 240

house
false
0
Rectangle -7500403 true true 45 120 255 285
Rectangle -16777216 true false 120 210 180 285
Polygon -7500403 true true 15 120 150 15 285 120
Line -16777216 false 30 120 270 120

house colonial
false
0
Rectangle -7500403 true true 270 75 285 255
Rectangle -7500403 true true 45 135 270 255
Rectangle -16777216 true false 124 195 187 256
Rectangle -16777216 true false 60 195 105 240
Rectangle -16777216 true false 60 150 105 180
Rectangle -16777216 true false 210 150 255 180
Line -16777216 false 270 135 270 255
Polygon -7500403 true true 30 135 285 135 240 90 75 90
Line -16777216 false 30 135 285 135
Line -16777216 false 255 105 285 135
Line -7500403 true 154 195 154 255
Rectangle -16777216 true false 210 195 255 240
Rectangle -16777216 true false 135 150 180 180

leaf
false
0
Polygon -7500403 true true 150 210 135 195 120 210 60 210 30 195 60 180 60 165 15 135 30 120 15 105 40 104 45 90 60 90 90 105 105 120 120 120 105 60 120 60 135 30 150 15 165 30 180 60 195 60 180 120 195 120 210 105 240 90 255 90 263 104 285 105 270 120 285 135 240 165 240 180 270 195 240 210 180 210 165 195
Polygon -7500403 true true 135 195 135 240 120 255 105 255 105 285 135 285 165 240 165 195

line
true
0
Line -7500403 true 150 0 150 300

line half
true
0
Line -7500403 true 150 0 150 150

pentagon
false
0
Polygon -7500403 true true 150 15 15 120 60 285 240 285 285 120

person
false
4
Circle -7500403 true false 110 5 80
Polygon -7500403 true false 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Rectangle -7500403 true false 127 79 172 94
Polygon -7500403 true false 195 90 240 150 225 180 165 105
Polygon -7500403 true false 105 90 60 150 75 180 135 105

person student
false
4
Polygon -13791810 true false 135 90 150 105 135 165 150 180 165 165 150 105 165 90
Polygon -7500403 true false 195 90 240 195 210 210 165 105
Circle -7500403 true false 110 5 80
Rectangle -7500403 true false 127 79 172 94
Polygon -7500403 true false 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Polygon -1 true false 100 210 130 225 145 165 85 135 63 189
Polygon -13791810 true false 90 210 120 225 135 165 67 130 53 189
Polygon -1 true false 120 224 131 225 124 210
Line -16777216 false 139 168 126 225
Line -16777216 false 140 167 76 136
Polygon -7500403 true false 105 90 60 195 90 210 135 105

plant
false
0
Rectangle -7500403 true true 135 90 165 300
Polygon -7500403 true true 135 255 90 210 45 195 75 255 135 285
Polygon -7500403 true true 165 255 210 210 255 195 225 255 165 285
Polygon -7500403 true true 135 180 90 135 45 120 75 180 135 210
Polygon -7500403 true true 165 180 165 210 225 180 255 120 210 135
Polygon -7500403 true true 135 105 90 60 45 45 75 105 135 135
Polygon -7500403 true true 165 105 165 135 225 105 255 45 210 60
Polygon -7500403 true true 135 90 120 45 150 15 180 45 165 90

sheep
false
15
Circle -1 true true 203 65 88
Circle -1 true true 70 65 162
Circle -1 true true 150 105 120
Polygon -7500403 true false 218 120 240 165 255 165 278 120
Circle -7500403 true false 214 72 67
Rectangle -1 true true 164 223 179 298
Polygon -1 true true 45 285 30 285 30 240 15 195 45 210
Circle -1 true true 3 83 150
Rectangle -1 true true 65 221 80 296
Polygon -1 true true 195 285 210 285 210 240 240 210 195 210
Polygon -7500403 true false 276 85 285 105 302 99 294 83
Polygon -7500403 true false 219 85 210 105 193 99 201 83

square
false
0
Rectangle -7500403 true true 30 30 270 270

square 2
false
0
Rectangle -7500403 true true 30 30 270 270
Rectangle -16777216 true false 60 60 240 240

star
false
0
Polygon -7500403 true true 151 1 185 108 298 108 207 175 242 282 151 216 59 282 94 175 3 108 116 108

target
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240
Circle -7500403 true true 60 60 180
Circle -16777216 true false 90 90 120
Circle -7500403 true true 120 120 60

tree
false
0
Circle -7500403 true true 118 3 94
Rectangle -6459832 true false 120 195 180 300
Circle -7500403 true true 65 21 108
Circle -7500403 true true 116 41 127
Circle -7500403 true true 45 90 120
Circle -7500403 true true 104 74 152

triangle
false
0
Polygon -7500403 true true 150 30 15 255 285 255

triangle 2
false
0
Polygon -7500403 true true 150 30 15 255 285 255
Polygon -16777216 true false 151 99 225 223 75 224

truck
false
0
Rectangle -7500403 true true 4 45 195 187
Polygon -7500403 true true 296 193 296 150 259 134 244 104 208 104 207 194
Rectangle -1 true false 195 60 195 105
Polygon -16777216 true false 238 112 252 141 219 141 218 112
Circle -16777216 true false 234 174 42
Rectangle -7500403 true true 181 185 214 194
Circle -16777216 true false 144 174 42
Circle -16777216 true false 24 174 42
Circle -7500403 false true 24 174 42
Circle -7500403 false true 144 174 42
Circle -7500403 false true 234 174 42

turtle
true
0
Polygon -10899396 true false 215 204 240 233 246 254 228 266 215 252 193 210
Polygon -10899396 true false 195 90 225 75 245 75 260 89 269 108 261 124 240 105 225 105 210 105
Polygon -10899396 true false 105 90 75 75 55 75 40 89 31 108 39 124 60 105 75 105 90 105
Polygon -10899396 true false 132 85 134 64 107 51 108 17 150 2 192 18 192 52 169 65 172 87
Polygon -10899396 true false 85 204 60 233 54 254 72 266 85 252 107 210
Polygon -7500403 true true 119 75 179 75 209 101 224 135 220 225 175 261 128 261 81 224 74 135 88 99

wheel
false
0
Circle -7500403 true true 3 3 294
Circle -16777216 true false 30 30 240
Line -7500403 true 150 285 150 15
Line -7500403 true 15 150 285 150
Circle -7500403 true true 120 120 60
Line -7500403 true 216 40 79 269
Line -7500403 true 40 84 269 221
Line -7500403 true 40 216 269 79
Line -7500403 true 84 40 221 269

wolf
false
0
Polygon -16777216 true false 253 133 245 131 245 133
Polygon -7500403 true true 2 194 13 197 30 191 38 193 38 205 20 226 20 257 27 265 38 266 40 260 31 253 31 230 60 206 68 198 75 209 66 228 65 243 82 261 84 268 100 267 103 261 77 239 79 231 100 207 98 196 119 201 143 202 160 195 166 210 172 213 173 238 167 251 160 248 154 265 169 264 178 247 186 240 198 260 200 271 217 271 219 262 207 258 195 230 192 198 210 184 227 164 242 144 259 145 284 151 277 141 293 140 299 134 297 127 273 119 270 105
Polygon -7500403 true true -1 195 14 180 36 166 40 153 53 140 82 131 134 133 159 126 188 115 227 108 236 102 238 98 268 86 269 92 281 87 269 103 269 113

x
false
0
Polygon -7500403 true true 270 75 225 30 30 225 75 270
Polygon -7500403 true true 30 75 75 30 270 225 225 270
@#$#@#$#@
NetLogo 6.4.0
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
default
0.0
-0.2 0 0.0 1.0
0.0 1 1.0 0.0
0.2 0 0.0 1.0
link direction
true
0
Line -7500403 true 150 150 90 180
Line -7500403 true 150 150 210 180
@#$#@#$#@
0
@#$#@#$#@
